package com.example.android.fechahora;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ConfirmacionActivity extends AppCompatActivity {
    TextView tvConfirmacion;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmacion);
        tvConfirmacion = this.findViewById(R.id.tvConfirmacion);
        Intent intent=this.getIntent();

        String datos="Paciente: "+  intent.getStringExtra("nombre")+"\n";
        datos+="Fecha: "+intent. getStringExtra("fecha")+"\n";
        datos+="Hora: "+intent.getStringExtra("hora")+"\n";
        datos+="Tipo cita: "+intent.getStringExtra("tipo");
        // Modificar mensaje
        tvConfirmacion.setText(datos);
    }
}
