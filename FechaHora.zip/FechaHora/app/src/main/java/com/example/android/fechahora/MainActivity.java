package com.example.android.fechahora;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView tvHora, tvFecha;
    EditText edtNombre;
    RadioGroup rgTipo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //obtenemos referencia a los controles
        tvFecha = this.findViewById(R.id.tvFecha);
        tvHora = this.findViewById(R.id.tvHora);
        edtNombre = this.findViewById(R. id.edtNombre);
        rgTipo= this.findViewById(R.id.rgTipo);
    }
    public void fecha(View view){
       // public DatePickerDialog (Context context, DatePickerDialog.OnDateSetListener listener, int year, int monthOfYear, int dayOfMonth)
        new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                //la fecha seleccionada la
                // mostramos en el TextView, hay que tener
                // en cuenta que los meses comienzan por 0
                tvFecha.setText(dayOfMonth+"/"+   (monthOfYear+1)+"/"+year);
            }
        },2016,3,20).show();
    }

    public void hora(View view){
        //public TimePickerDialog(Context context, TimePickerDialog.OnTimeSetListener listener, int hourOfDay, int minute, boolean is24HourView)
        //creamos y mostramos cuadro de diálogo de hora
        //new TimePickerDialog(this,Listener, 10,20,true).show();
        new TimePickerDialog(this,new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {                                      //la hora seleccionada la mostramos en el TextView
                tvHora.setText(minute + ":" + hourOfDay);
            }
        }, 10,20,true).show();
    }

    public void citar(View view){
        int res = rgTipo.getCheckedRadioButtonId();
        // Si no se rellenan los campos, no se debe lanzar ni crear 2ª activity!!
        // Lógica aquí....
        if(edtNombre.getText().toString().length()==0){
            Toast toast = Toast.makeText(getApplicationContext(),
                    "Por favor, rellena nombre", Toast.LENGTH_SHORT);
            toast.show();
        }else if(tvFecha.getText()==""){
            Toast toast =Toast.makeText(getApplicationContext(),
                    "Por favor, rellena fecha", Toast.LENGTH_SHORT);
            toast.show();
        }else if(tvHora.getText()==""){
            Toast toast =Toast.makeText(getApplicationContext(),
                    "Por favor, rellena hora", Toast.LENGTH_SHORT);
            toast.show();
        }else if(res != R.id.rbGeneral && res != R.id.rbPediatria){
            Toast toast =Toast.makeText(getApplicationContext(),
                    "Por favor, Marca pediatria/general", Toast.LENGTH_SHORT);
            toast.show();

        }else{ // Todo OK
            Intent intent = new Intent(this,ConfirmacionActivity.class);
            intent.putExtra("nombre", edtNombre.getText().toString());
            intent.putExtra("fecha",tvFecha.getText());
            intent.putExtra("hora",tvHora.getText());


            switch (res){
                case R.id.rbGeneral:
                    intent.putExtra("tipo","Medicina general");
                    break;
                case R.id.rbPediatria:
                    intent.putExtra("tipo","Pediatría");
                    break;
            }
            //lanzamos la actividad
            this.startActivity(intent);

        }


    }
}

