package com.example.android.cuadrosdialogo;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.util.ArrayList;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class CalculosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_calculos);

        Intent intent = this.getIntent();
        ArrayList<Double> notas = (ArrayList<Double>) intent.getSerializableExtra("notas");

        TextView tvMedia = this.findViewById(R.id.tvMedia);
        TextView tvAprobados = this.findViewById(R.id.tvAprobados);

        // Modificar los textview
        tvMedia.setText("Nota media: " + media(notas));
        tvAprobados.setText("Aprobados: " + aprobados(notas));


    }
    private double media(ArrayList<Double> notas) {
        double total = 0;
        for (Double n : notas) {
            total += n; // result = result + n
        }
        return total / notas.size();
    }
    private int aprobados(ArrayList<Double> notas) {
        int total = 0;
        for (Double n : notas) {
            if (n >= 5) {
                total++; // result = result + 1
            }
        }
        return total;
    }
    public void salir(View view){
        // Codigo cuadro dialogo
        // Dialogo de alerta
        AlertDialog.Builder cuadro = new AlertDialog.Builder(this);
        cuadro.setMessage("¿Desea salir de la actividad");
        // Escuchador de botones SI/NO
        cuadro.setPositiveButton("OK",  new DialogInterface.OnClickListener() {
            // MI codigo de listener
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //Abandona la actividad
                CalculosActivity.this.finish();
            }
        });
        cuadro.setNegativeButton("CANCEL",null);

        // Mostrar el cuadro de dialogo
        cuadro.show();
    }
}
