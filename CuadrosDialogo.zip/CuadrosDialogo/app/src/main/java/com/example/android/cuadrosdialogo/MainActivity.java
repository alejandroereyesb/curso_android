package com.example.android.cuadrosdialogo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Double> notas; // Si NO hay notas, no quiero que se lance el 2º activity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        notas = new ArrayList<>();
    }

    public void guardar(View v){
        EditText edtNota= this.findViewById(R.id.edtNota);
        notas.add(Double.parseDouble(edtNota.getText().toString()));
        //borra el contenido del campo nota
        edtNota.setText("");
        //pasa el foco a dicho control
        edtNota.requestFocus();
    }
    public void calculos(View v){
        // Sacar mensaje de un toast


        if(notas.size()>0) {
            Intent intent = new Intent(this, CalculosActivity.class);
            intent.putExtra("notas", notas);
            this.startActivity(intent);
        }else{
            //Toast
            Toast notificacion = Toast.makeText(this,"No hay notas!", Toast.LENGTH_LONG);
            notificacion.show();
        }

    }
}
